#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void easy();
void medium();
void hard();

int easyArray [4];
int mediumArray [4];
int hardArray [4];

int playerArray[4];

main ()
{
	int i, j, choice, turns = 0;
	int digit1, digit2, digit3, digit4;
	int blackPeg = 0, whitePeg = 0;

	// Menu
	printf("\n ______________Welcome to the game Mastermind______________");
	printf("\n The rules of the game are as follows...");
	printf("\n At the start of the game,a 4 random couloured sequence of pegs are generated");
	printf("\n Your goal is to guess the correct pattern of the pegs in 15 turns");
	printf("\n You do so by entering numbers, 1-7 which all identify different colours");
	printf("\n 1=Red, 2=Orange, 3=Yellow, 4=Green, 5=Blue, 6=Indigo, 7=Violet");
	printf("\n For hard mode, there can be black spaces, denoted by 0");
	printf("\n___________________________________________________________");
	printf("\nEasy mode   - Guess 4 pegs with no repetition and no blank spaces");
	printf("\nMedium mode - Guess 4 pegs with repetition and no blank spaces");
	printf("\nHard mode   - Guess 4 pegs with repetition and blank spaces");
	printf("\n___________________________________________________________");

	// Difficulty selection
	printf("\n\nSelect a difficulty(1 = Easy, 2 = Medium, 3 = Hard): ");
	fflush(stdin);
	scanf("%d", &choice);

	// Simple error handling for wrong difficulty chosen
	if (choice != 1 && choice != 2 && choice != 3)
	{
		do
		{
			printf("Invalid selection!\n");
			printf("\nSelect a difficulty(1 = Easy, 2 = Medium, 3 = Hard): ");
			fflush(stdin);
			scanf("%d", &choice);
		}while (choice != 1 && choice != 2 && choice != 3);
	}

	if(choice == 1)
	{
		// Play game on easy until player has run out of turns(set above)
		// or until player guesses all the pegs correctly

		easy();

		do
		{
			turns++;

			printf("\nEnter your guess for digit 1: ");
			scanf("%d", &digit1);
			fflush(stdin);

			printf("Enter your guess for digit 2: ");
			scanf("%d", &digit2);
			fflush(stdin);

			printf("Enter your guess for digit 3: ");
			scanf("%d", &digit3);
			fflush(stdin);

			printf("Enter your guess for digit 4: ");
			scanf("%d", &digit4);
			fflush(stdin);

			// Assigning player values to a playerArray to then compare against easyArray
			playerArray[0] = digit1;
			playerArray[1] = digit2;
			playerArray[2] = digit3;
			playerArray[3] = digit4;

			blackPeg = 0;
			whitePeg = 0;
			for(i = 0; i < 4; i++)
			{
				if (easyArray[i] == playerArray[i])
				{
					blackPeg++;
				}
				for(j = 0; j < 4; j++)
				{
					if (easyArray[i] == playerArray[j] && easyArray[i] != playerArray[i])
					{
						whitePeg++;
					}
				}
			}

			printf("\nBlack Pegs: %d, White Pegs: %d", blackPeg, whitePeg);
		
			printf("\n\n");
		
			if (blackPeg == 4)
			{
				printf("You have won easy mode in %d turns! Congratulations!", turns);
				break;
			}

			if (turns == 15)
			{
				printf("Sorry, you were not able to beat easy mode in 15 turns. Try again!");
				break;
			}
		}while (blackPeg != 4);
	}
	else if(choice == 2)
	{
		// Play game on medium until player has run out of turns(set above)
		// or until player guesses all the pegs correctly

		medium();

		do
		{
			turns++;

			printf("\nEnter your guess for digit 1: ");
			scanf("%d", &digit1);
			fflush(stdin);

			printf("Enter your guess for digit 2: ");
			scanf("%d", &digit2);
			fflush(stdin);

			printf("Enter your guess for digit 3: ");
			scanf("%d", &digit3);
			fflush(stdin);

			printf("Enter your guess for digit 4: ");
			scanf("%d", &digit4);
			fflush(stdin);

			// Assigning player values to a playerArray to then compare against mediumArray
			playerArray[0] = digit1;
			playerArray[1] = digit2;
			playerArray[2] = digit3;
			playerArray[3] = digit4;

			blackPeg = 0;
			whitePeg = 0;
			for(i = 0; i < 4; i++)
			{
				if (mediumArray[i] == playerArray[i])
				{
					blackPeg++;
					continue;
				}
				for(j = 0; j < 4; j++)
				{
					if (mediumArray[i] == playerArray[j] && mediumArray[i] != playerArray[i])
					{
						whitePeg++;
						break;
					}
				}
			}

			printf("\nBlack Pegs: %d, White Pegs: %d", blackPeg, whitePeg);
		
			printf("\n\n");
			
			if (blackPeg == 4)
			{
				printf("You have won medium mode in %d turns! Congratulations!", turns);
				break;
			}

			if (turns == 15)
			{
				printf("Sorry, you were not able to beat medium mode in 15 turns. Try again!");
				break;
			}
		}while (blackPeg != 4);
	}
	else if(choice == 3)
	{
		// Play game on hard until player has run out of turns (15)
		// or until player guesses all the pegs correctly

		hard();

		do
		{
			turns++;

			printf("\nEnter your guess for digit 1: ");
			scanf("%d", &digit1);
			fflush(stdin);

			printf("Enter your guess for digit 2: ");
			scanf("%d", &digit2);
			fflush(stdin);

			printf("Enter your guess for digit 3: ");
			scanf("%d", &digit3);
			fflush(stdin);

			printf("Enter your guess for digit 4: ");
			scanf("%d", &digit4);
			fflush(stdin);

			// Assigning player values to a playerArray to then compare against hardArray
			playerArray[0] = digit1;
			playerArray[1] = digit2;
			playerArray[2] = digit3;
			playerArray[3] = digit4;

			blackPeg = 0;
			whitePeg = 0;
			for(i = 0; i < 4; i++)
			{
				if (hardArray[i] == playerArray[i])
				{
					blackPeg++;
					continue;
				}
				for(j = 0; j < 4; j++)
				{
					if (hardArray[i] == playerArray[j] && hardArray[i] != playerArray[i])
					{
						whitePeg++;
						break;
					}
				}
			}

			printf("\nBlack Pegs: %d, White Pegs: %d", blackPeg, whitePeg);
		
			printf("\n\n");
		
			if (blackPeg == 4)
			{
				printf("You have won hard mode in %d turns! Congratulations!", turns);
				break;
			}

			if (turns == 15)
			{
				printf("Sorry, you were not able to beat hard mode in 15 turns. Try again!");
				break;
			}
		}while (blackPeg != 4);
	} 

	printf("\n\n");
	system("pause");
} // end of main

// For all of these methods, I've commented out a for loop at the end that writes the sequence to screen (If you can't beat the game).

void easy () 
{ 
	// Generating a random peg sequence without repetitions or blank spaces
	int i;

	srand(time(NULL));

	for (i = 0; i < 4; i++)
	{
		easyArray[i] = rand()%7+1;

		if(i == 1)
		{
			if(easyArray[i] == easyArray[i-1])
			{
				do
				{
					easyArray[i] = rand()%7+1;
				}while(easyArray[i] == easyArray[i-1]);
			}
		}

		if(i == 2)
		{
			if(easyArray[i] == easyArray[i-1]  || easyArray[i] == easyArray[i-2])
			{
				do
				{
					easyArray[i] = rand()%7+1;
				}while(easyArray[i] == easyArray[i-1] || easyArray[i] == easyArray[i-2]);
			}
		}

		if(i == 3)
		{
			if(easyArray[i] == easyArray[i-1]  || easyArray[i] == easyArray[i-2] || easyArray[i] == easyArray[i-3])
			{
				do
				{
					easyArray[i] = rand()%7+1;
				}while(easyArray[i] == easyArray[i-1] || easyArray[i] == easyArray[i-2] || easyArray[i] == easyArray[i-3]);
			}
		}
	}

	printf("\n\n");

	/* for (i = 0; i < 4; i++)
	{
		printf("%d", easyArray[i]);
	} */
}

void medium ()
{
	// Generating a random peg sequence with repetitions but no blank spaces
	int i;

	srand(time(NULL));

	for (i = 0; i < 4; i++)
	{
		mediumArray[i] = rand()%7+1;
	}

	printf("\n\n");

	/* for (i = 0; i < 4; i++)
	{
		printf("%d", mediumArray[i]);
	} */
}

void hard ()
{
	// Generating a random peg sequence with repetitions and blank spaces
	int i;

	srand(time(NULL));

	for (i = 0; i < 4; i++)
	{
		hardArray[i] = rand()%7;
	}

	printf("\n\n");

	/* for (i = 0; i < 4; i++)
	{
		printf("%d", hardArray[i]);
	} */
}