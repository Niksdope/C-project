Mastermind game made by Niks Gurins - G00315379
Got it working fine apart from keeping the high scores and best rounds etc.
Submitting this to GitHub and OneDrive